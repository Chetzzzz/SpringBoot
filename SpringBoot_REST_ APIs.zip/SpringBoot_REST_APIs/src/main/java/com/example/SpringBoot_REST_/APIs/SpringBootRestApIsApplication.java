package com.example.SpringBoot_REST_.APIs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestApIsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestApIsApplication.class, args);
	}

}
